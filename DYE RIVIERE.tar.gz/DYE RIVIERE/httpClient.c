// tcp_client.c

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


int main(void) {

  char domaine[256];
  char fichier[256];
  int port;
  struct hostent * ip;

  printf("Bienvenue dans le systeme de connexion HTTP de M.DYE et M.RIVIERE\n Veuillez saisir le domaine auquel vous souhaitez acceder : ");
  fgets(domaine, 256, stdin);
  char *p = strchr(domaine,'\n');
  *p = '\0';
  
  printf("\nVeuillez saisir le fichier auquel vous souhaitez acceder (vide pour l'index) : ");
  fgets(fichier, 256, stdin);
  p = strchr(fichier,'\n');
  *p = '\0';
  if((int)strlen(fichier)<1){
    char indexLibelle[20]="index.html";
    strcpy(fichier,indexLibelle);
    printf("%s\n", fichier);
  }
  
  printf("\nVeuillez saisir le port : ");
  scanf("%d", &port);
  
  printf("Merci ! Veuillez patienter nous procédons à l execution de votre requete\n");
  sleep(1);printf(".\n");sleep(1);printf("..\n");sleep(1);printf("...\n");
  
  ip=gethostbyname(domaine);

  int sock;
  struct sockaddr_in sin;

  /* Creation de la socket */
  sock = socket(AF_INET, SOCK_STREAM, 0);
 
  /* Configuration de la connexion */
  sin.sin_addr = *(struct in_addr *) ip->h_addr;
  sin.sin_family = AF_INET;
  sin.sin_port = htons(port);
 
  /* Tentative de connexion au serveur */
  connect(sock, (struct sockaddr*)&sin, sizeof(sin));
  printf("Connexion a %s sur le port %d\n", inet_ntoa(sin.sin_addr),
         htons(sin.sin_port));

  //Envoie GET
  char reqGET[512] ="GET /"; char suiteReqGET[32]=" HTTP/1.1\nHost : "; char finReqGET[6]="\n\n";
  strcat(reqGET,fichier); strcat (reqGET,suiteReqGET); strcat(reqGET,domaine); strcat(reqGET,finReqGET);
  char answGET[4096];
  printf("%s", reqGET);
  send(sock, reqGET, sizeof(reqGET), 0);
  recv(sock, answGET, sizeof(answGET), 0);
  printf("%s\n", answGET);

  FILE * fic;
  fic = fopen("maReponse.html","w");
  fprintf(fic, "%s", answGET);
  fclose(fic);
  //execv("firefox maReponse.html", argv[0]);

  /* Fermeture de la socket client */
  close(sock);

  return EXIT_SUCCESS;

}//main
